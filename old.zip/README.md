# konde
